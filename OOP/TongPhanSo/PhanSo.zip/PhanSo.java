public class PhanSo{
    private long tuso1, mauso1,tuso2,mauso2;
    public PhanSo(long tuso1,long mauso1,long tuso2, long mauso2)
    {
        this.tuso1=tuso1;
        this.mauso1=mauso1;
        this.tuso2=tuso2;
        this.mauso2=mauso2;
    }
    private long uc(long tu,long mau)
    {
        while(tu*mau!=0)
        {
            if(tu>mau) tu%=mau;
            else mau%=tu;
        }
        return tu+mau;
    }
    private long tuso()
    {
        long t1=uc(tuso1,mauso1),t2=uc(tuso2,mauso2);
        return (tuso1/t1)*(mauso2/t2)+(tuso2/t2)*(mauso1/t1);
    }
    private long mauso()
    {
        long t1=uc(tuso1,mauso1),t2=uc(tuso2,mauso2);
        return (mauso1/t1)*(mauso2/t2);
    }


    @Override
    public String toString() {
        return tuso()/uc(tuso(),mauso())+"/"+mauso()/uc(tuso(),mauso());
    }
}