import java.util.*;

;public class Main {
    public static void main(String[] args) {
        Scanner in=new Scanner(System.in);
        PhanSo ps = new PhanSo(in.nextLong(), in.nextLong());
        System.out.println(ps);
    }
}
