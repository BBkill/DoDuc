package TinhGio;

public class MonHoc extends  LopHocPhan{
    MonHoc(){}
    protected String tenMonHoc;

    public void setTenMonHoc(String tenMonHoc) {
        this.tenMonHoc = tenMonHoc;
    }

    public String getTenMonHoc() {
        return tenMonHoc;
    }



}
