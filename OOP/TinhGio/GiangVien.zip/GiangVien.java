package TinhGio;

public class GiangVien extends LopHocPhan{
    protected String tenGiangVien;
    GiangVien(){}
    public String getTenGiangVien() {
        return tenGiangVien;
    }

    public void setTenGiangVien(String tenGiangVien) {
        this.tenGiangVien = tenGiangVien;
    }
}
