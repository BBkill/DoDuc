package TinhGio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int soMH= Integer.parseInt(input.nextLine());
        ArrayList<MonHoc> listMonHoc = new ArrayList<>();
        for(int i=0;i<soMH;i++)
        {
            MonHoc monHoc = new MonHoc();
            monHoc.setMaMonHoc(input.next());
            monHoc.setTenMonHoc(input.nextLine().trim());
            listMonHoc.add(monHoc);
        }
        int soGV = Integer.parseInt(input.nextLine());
        ArrayList<GiangVien> listGiangVien = new ArrayList<>();
        for (int i = 0; i < soGV; i++) {
            GiangVien giangVien = new GiangVien();
            giangVien.setMaGV(input.next());
            giangVien.setTenGiangVien(input.nextLine().trim());
            listGiangVien.add(giangVien);
        }
        int soLHP = Integer.parseInt(input.nextLine());
        ArrayList<LopHocPhan> listlopHocPhan= new ArrayList<>();
        for (int i = 0; i < soLHP; i++) {
            LopHocPhan lophoc = new LopHocPhan();
            lophoc.setMaGV(input.next());
            lophoc.setMaMonHoc(input.next());
            lophoc.setSoGio(Float.parseFloat(input.nextLine().trim()));
            listlopHocPhan.add(lophoc);
        }
        String filte = input.nextLine();
        for (GiangVien giangvien: listGiangVien) {
            if(giangvien.getMaGV().equals(filte))
            {
                float tongSoGio=0f;
                System.out.println("Giang vien: "+giangvien.getTenGiangVien());
                for (LopHocPhan hocphan: listlopHocPhan) {
                    if(hocphan.getMaGV().equals(filte))
                    {
                        for (MonHoc monhoc: listMonHoc) {
                            if(monhoc.getMaMonHoc().equals(hocphan.getMaMonHoc()))
                            {
                                System.out.println(monhoc.getTenMonHoc()+" "+hocphan.getSoGio());
                                tongSoGio+=hocphan.getSoGio();
                                break;
                            }
                        }
                    }
                }
                System.out.println("Tong: "+String.format("%.2f",tongSoGio));
                break;
            }
        }

    }
}
