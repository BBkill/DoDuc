import java.text.DecimalFormat;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner ip=new Scanner(System.in);
        //while(true)
        
            SinhVien sv= new SinhVien(ip.nextLine(),ip.nextLine(),ip.nextLine(),ip.nextFloat());
            System.out.println(sv);
        
        
    }
}
