package LopPair;

public class Pair <T1, T2> {
    private Integer first;
    private Integer second;
    Pair(Integer first,Integer second)
    {
        this.first = first;
        this.second = second;
    }

    public boolean isPrime()
    {
        if((int)first < 2 || (int)second < 2) return false;
        for(int i = 2;i*i<=first;i++)
        {
            if(first%i==0) return false;
        }
        for(int i = 2;i*i<=second;i++)
        {
            if(second%i==0) return false;
        }
        return true;
    }
    @Override
    public String toString() {
        return first+" "+second;
    }
}
