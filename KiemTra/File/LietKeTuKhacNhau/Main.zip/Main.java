package LietKeTuKhacNhau;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        WordSet ws = new WordSet("D:/ZJava/KiemTra/File/VANBAN.txt");
        System.out.println(ws);
    }
}
